<?php
return [
    'profile_updated_successfully' => 'Profile updated successfully',
    'current_user_is' => 'Current user profile',
];
