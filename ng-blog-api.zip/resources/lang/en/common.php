<?php
return [
    'data_returned_successfully' => 'Data returned successfully',
    'some_error' => 'Some error occurred !',
    'password_updated' => 'Password updated successfully',
    'logged_out_successfully' => 'Logged out successfully',
    'login_successful' => 'login successful !',
    'signup_successful' => 'Signup done successfully',
];
