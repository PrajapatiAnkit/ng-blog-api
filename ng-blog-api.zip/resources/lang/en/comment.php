<?php
return [
    'comment_added_successfully' => 'Comment has been added successfully !',
];
