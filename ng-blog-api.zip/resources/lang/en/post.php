<?php
return [
    'post_saved_successfully' => 'Post has been saved successfully !',
    'marked_favorites' => 'Post marked as favorite for u ! :)',
    'marked_un_favorites' => 'Post marked as un-favorite for u ! :)',
];
