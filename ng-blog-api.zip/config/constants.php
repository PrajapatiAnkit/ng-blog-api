<?php
return [
  'paths' => [
      'thumbnail' => '/uploads/thumbnail/',
      'profile' => '/uploads/profile/',
  ]
];
